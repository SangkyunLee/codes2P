
addpath('.\lib')
Folder= '.\'
nexfile ='0003.nex'




%-------------------------------------------------------
s = nex2mat(Folder,nexfile);
timestamps = s.nexData.markers{1}.timestamps;
s = setTimeStamp(s,timestamps);
%retrieve the full set of stimulus events lookup table from s.
%retrieve marker from nex file
marker = s.nexData.markers{1};
%stim variable set
encode_vars = cell(1,length(marker.values));
for j = 1 : length(marker.values)
    encode_vars{j} = marker.values{j}.name;
end
%keywords for event-sorting. full set of LUT returned when all variables
%are true, i.e, '>0'
event = struct;
for j = 1 : length(encode_vars)
    event(j).type = encode_vars{j};
    event(j).string = '>0';
    event(j).operator = '&';
end
%retrive the full set of stim-event-lookup table.
[t_SETS,StimEventLUT] = sortStimEvent(s,event);
cond.t_SETS = t_SETS;
cond.StimEventLUT =StimEventLUT;
cond.event = event;